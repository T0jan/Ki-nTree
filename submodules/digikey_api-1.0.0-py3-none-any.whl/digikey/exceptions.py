class DigikeyError(Exception):
    pass


class DigikeyTypeError(Exception):
    pass


class DigikeyOauthException(Exception):
    pass
