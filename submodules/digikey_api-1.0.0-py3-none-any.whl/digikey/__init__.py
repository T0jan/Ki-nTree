from digikey.v4.api import (keyword_search, product_details, digi_reel_pricing, suggested_parts,
                            )
from digikey.v4.api import (status_salesorder_id, salesorder_history)
from digikey.v4.api import (batch_product_details)

name = 'digikey'
